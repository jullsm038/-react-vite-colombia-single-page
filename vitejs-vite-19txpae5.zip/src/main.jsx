import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom'; // ← agregar
import './index.css';
import App from './App.jsx';

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <BrowserRouter>
      {' '}
      {/* ← agregar */}
      <App />
    </BrowserRouter>{' '}
    {/* ← agregar */}
  </StrictMode>
);
